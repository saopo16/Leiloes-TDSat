# Leilões-TDSat

## Descrição

O projeto Leilões-TDSat é uma aplicação desenvolvida para uma casa de leilões, visando modernizar e informatizar suas rotinas. A plataforma tem como objetivo facilitar a gestão de leilões, permitindo o cadastro de itens, a participação de usuários e o registro de lances de forma eficiente.

Este repositório contém o código-fonte do projeto, e qualquer contribuição é bem-vinda. Fique à vontade para explorar, sugerir melhorias e colaborar no desenvolvimento.

## Tecnologias Utilizadas

- [Java]
- [MySQL]

Até o momento, a implementação foi feita utilizando essas tecnologias. Entretanto, é importante destacar que novas tecnologias podem ser incorporadas ao longo do desenvolvimento, aprimorando ainda mais a aplicação.


